@echo off
setlocal
start "" /D "%~dp0runtime" "%~dp0runtime\standard_tool.exe"
if errorlevel 1 pause
