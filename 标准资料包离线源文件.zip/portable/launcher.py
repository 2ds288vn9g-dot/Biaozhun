"""Windows 离线包启动入口：启动本机 Streamlit 页面。"""
from __future__ import annotations

import sys
import threading
import time
import webbrowser
from pathlib import Path

from streamlit.web import cli as stcli


ROOT = Path(sys.executable).resolve().parent
APP = ROOT / "app.py"
PORT = 8765


def open_browser() -> None:
    time.sleep(1.5)
    webbrowser.open(f"http://127.0.0.1:{PORT}")


if __name__ == "__main__":
    if not APP.exists():
        raise SystemExit("启动失败：未找到 app.py，请保持离线包目录结构完整。")
    threading.Thread(target=open_browser, daemon=True).start()
    sys.argv = [
        "streamlit",
        "run",
        str(APP),
        "--server.address",
        "127.0.0.1",
        "--server.port",
        str(PORT),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
    ]
    stcli.main()
