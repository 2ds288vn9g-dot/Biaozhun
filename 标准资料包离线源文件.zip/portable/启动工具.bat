@echo off
chcp 65001 >nul
title 标准资料包生成平台（离线网页启动版）
cd /d "%~dp0运行程序"
start "" "标准资料包生成平台.exe"
pause
